# P5 V2 — suggestions and implementation matrix

**Date:** 27 August 2026  
**Scope:** active P5 V2 plans, web-research recommendations, DAR, manuscript, and submission package.

## Implemented

| Suggestion | Evidence | Status |
|---|---|---|
| Keep the result panel-specific and avoid universal GNN/Transformer claims | P5 V2 manuscript Discussion/Limitations | `IMPLEMENTED` |
| Separate primary benchmark from robustness analyses | manuscript structure; `P5_DATA_ANALYSIS_REPORT.md` | `IMPLEMENTED` |
| Use independent scaffold partitions | `results/extended_campaign_20260825/robustness/split_audit.json` and aggregates | `IMPLEMENTED` |
| Report AUPRC alongside ROC-AUC | fold predictions and aggregate tables | `IMPLEMENTED` |
| Paired native/permuted descriptor comparisons | `paired_ablation_contrasts.csv` | `IMPLEMENTED_SECONDARY` |
| Report salience stability and caveat non-causality | `salience_stability.csv`; manuscript caveats | `IMPLEMENTED_SECONDARY` |
| Audit chemical standardization and tautomer collisions | `chemical_standardization_audit.json` | `IMPLEMENTED_AUDIT` |
| Audit ChEMBL threshold sensitivity | `chembl_threshold_sensitivity.json` | `IMPLEMENTED_RF_ONLY` |
| Complete and audit ChemBERTa extension | `chemberta_completion_audit_20260827.json` | `IMPLEMENTED_SECONDARY` |
| Include study-design and effect-summary tables | `Table_P5_Study_Design.tex`, `Table_P5_Effect_Summary.tex` | `IMPLEMENTED` |
| Keep LISH orthogonal and non-comparable to malaria activity AUC | DAR and manuscript | `IMPLEMENTED` |
| Use fixed seeds/folds and finite-value gates | campaign configuration, fold files, audit | `IMPLEMENTED` |
| Prepare a clean reproducibility/deposit package | `zenodo_package_20260827/` and archive | `IMPLEMENTED_LOCAL_ONLY` |
| Add a position section vs recent representation benchmarks (Guo & Ding 2026, 25-embedding benchmark, Boldini 2024) | manuscript Discussion "Position relative to recent representation benchmarks" | `IMPLEMENTED` |
| Move the LISH phenotype-only benchmark to Supporting Information | `P5_SI_V2608.tex` (Section S1), 7 main-text pointers | `IMPLEMENTED` |
| Light GNN hyperparameter sensitivity (hidden/dropout) on the scaffold split | SLURM **15617** (`p5_sensitivity_gnn.sbatch`, configs `_sens_h64_d02` / `_sens_h256_d01`) | `COMPLETED` (outputs audited and integrated into the 31-file Zenodo package) |
| Add `--hidden`/`--dropout` CLI options to the P5 benchmark | `scripts/p5_benchmark.py`; dry-run validated | `IMPLEMENTED` |
| Post-hoc calibration metrics (ECE, MCE, Brier, reliability) on the archived fold predictions | `results/calibration_20260827/` (`scripts/p5_calibration_posthoc.py`; 30 configs = 25 GNN + 5 ChemBERTa, pooled over 25 fold-seed records each) | `COMPUTED_SECONDARY` |

## Implemented at DAR level but not fully manuscript-integrated

| Suggestion | Evidence | Status |
|---|---|---|
| Explicit OOD hierarchy (random < scaffold < cluster-based) | web-research plan and DAR caveats | `DOCUMENTED; NOT_NEWLY_COMPUTED` |
| Practical paired-effect interpretation | aggregate and paired-contrast CSVs | `DAR_READY; MANUSCRIPT_REVIEW_REQUIRED` |
| Detailed fold scaffold size/prevalence table | split audit artifacts | `AUDIT_AVAILABLE; DEDICATED_TABLE_NOT_GENERATED` |
| Nearest-training-neighbor similarity breakdown | existing similarity diagnostics are partial | `PARTIAL; DEDICATED_BREAKDOWN_NOT_COMPUTED` |

## Not computed and intentionally not fabricated

| Suggestion | Reason | Status |
|---|---|---|
| ChemBERTa calibration curves, calibration slope/intercept, reliability diagrams | post-hoc ECE/MCE/Brier/reliability computed 27/08/2026 on the archived fold predictions (`results/calibration_20260827/`); slope/intercept fits and recalibrated-model variants remain `NOT_COMPUTED` (no retraining performed) | `COMPUTED_SECONDARY_POSTHOC` (metrics); `NOT_COMPUTED` (recalibration) |
| Full OOD distance-to-nearest-training-neighbor analysis for every model | no locked analysis artifact and no predeclared estimator in the current campaign | `NOT_COMPUTED` |
| Cluster-based/Butina split retraining | new split and new training campaign required | `NOT_COMPUTED` |
| Prospective experimental validation | outside computational scope | `NOT_COMPUTED` |
| VAE, Graphormer, Bayesian optimization, contrastive pretraining, conditional generation | stretch/post-v1 ideas, not required for the current paper | `NOT_COMPUTED` |
| Zenodo upload and DOI verification | requires external author-controlled action | `PENDING_EXTERNAL_AUTHOR_ACTION` |

## Final interpretation

All P5 V2 suggestions required for the current submission-quality article and supported by existing evidence are implemented or explicitly documented. The remaining items are either optional new experiments, dedicated analyses requiring a predeclared protocol, or external author actions. None should be silently described as completed.
